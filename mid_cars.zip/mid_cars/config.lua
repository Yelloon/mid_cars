config = {}

config.Base = "vrpex" -- configuração de base, "bahamas", "vrpex", "creative"

config.start = vector3(859.14, -2132.22, 30.55) -- Localização para iniciar 

config.pagamento = math.random(275,500) -- Minimo e Maximo de pagamento

config.locations = { --Localizações para spawnar o carro
    {605.54, 126.28, 92.91},
    {-50.13, -1478.62, 31.93},
    {-1100.78, -1632.18, 4.41},
    {1028.5, -770.72, 58.04},
    {247.61, -1408.1, 30.59},
    {1776.54, 3340.06, 41.07},
    {2364.41, 3107.26, 47.83},
    {-1016.8, -307.54, 37.61},
    {110.48, -1932.83, 20.6},
    {-1567.86, -889.43, 9.17},
    {240.84, -1741.39, 30.04},
    {-431.42, -1702.32, 18.77},
    {1482.44, 3581.04, 35.14},
    {-232.14, -1176.41, 23.23},
    {985.71, -1410.65, 31.25},
}

config.time = 300000 -- Tempo de spawn do carro 
